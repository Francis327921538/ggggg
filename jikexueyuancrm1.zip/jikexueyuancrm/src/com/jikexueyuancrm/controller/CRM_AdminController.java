package com.jikexueyuancrm.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ObjectUtils.Null;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jikexueyuancrm.entity.CRM_Admin;
import com.jikexueyuancrm.service.ICRM_AdminService;



@Controller
@RequestMapping("/admin")
public class CRM_AdminController {
	
	@Resource
	ICRM_AdminService adminService;
	
	@ResponseBody
	@RequestMapping("/login")
	public boolean login(HttpServletRequest request, HttpServletResponse response){
		
		String admin_account = request.getParameter("admin_account");
		String admin_password = request.getParameter("admin_password");
		CRM_Admin admin = adminService.adminLogin(admin_account, admin_password);
		request.setAttribute("admin", admin);
		if (admin!=null) {
			HttpSession session = request.getSession();
			session.setAttribute("currAdmin", admin);
			return true;
		}
		return false;
	}
	
	@RequestMapping("hello")
	public void hello(){
		System.out.println("admin");
	}
	
}
