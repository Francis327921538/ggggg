package com.jikexueyuancrm.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jikexueyuancrm.entity.CRM_Customer;
import com.jikexueyuancrm.service.ICRM_CustomerService;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("/customer")
public class CRM_CustomerController {
	
	@Resource
	ICRM_CustomerService customerService;
	
	@RequestMapping("/hello")
	public ModelAndView hello(){
		
		ModelAndView modelAndView = new ModelAndView("hello");
		List<CRM_Customer> customers = new ArrayList<>();
		customers = customerService.getAllCustomer();
		modelAndView.addObject("cus", customers);
		return modelAndView;
	}
//	@ResponseBody
//	@RequestMapping("/cus")
//	public Map listAllCustomerAjax(){
//		
//		System.out.println("cus1");
//		List<CRM_Customer> customers = customerService.getAllCustomer();
//		Map<String,Object> map = new HashMap<String,Object>();
//		map.put("cus", customers);
//		return map;
//	}
	@ResponseBody
	@RequestMapping("/lsitCustomer")
	public List<CRM_Customer> listAllCustomerAjax(){
		
		List<CRM_Customer> customers = customerService.getAllCustomer();
		return customers;
	}
	
	@RequestMapping("/say")
	public void say(HttpServletRequest request, HttpServletResponse response){
		
		System.out.println(request.getParameter("hello"));
		System.out.println("hello");
	}
	
	@ResponseBody
	@RequestMapping("deleteCustomer")
	public boolean deleteCustomerByID(HttpServletRequest request, HttpServletResponse response){
		
		System.out.println("deleteCus");
		int id = Integer.parseInt(request.getParameter("currCustomer"));
		System.out.println(id);
		customerService.deleteCustomerByID(id);
		return true;
	}
	
	@ResponseBody
	@RequestMapping("addCustomer")
	public boolean addCustomer(HttpServletRequest request, HttpServletResponse response){
		
		String customerStr = request.getParameter("customer");
		//string ת json
		JSONObject jsonObject = JSONObject.fromObject(customerStr);
		//json ת object
		CRM_Customer customer = (CRM_Customer) JSONObject.toBean(jsonObject, CRM_Customer.class);
		
		customerService.addCustomer(customer);
		return true;
		
	}
}
