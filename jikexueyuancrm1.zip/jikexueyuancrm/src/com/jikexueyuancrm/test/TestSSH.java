package com.jikexueyuancrm.test;

import static org.junit.Assert.fail;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jikexueyuancrm.entity.CRM_Admin;
import com.jikexueyuancrm.entity.CRM_Customer;

public class TestSSH {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

	private ApplicationContext ctx = null;

	@Test
	public void testDataSource() throws SQLException {
		ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		// System.out.println(ctx);
		DataSource dataSource = ctx.getBean(DataSource.class);

		// System.out.println(dataSource.getConnection().toString());

		SessionFactory sessionFactory = ctx.getBean(SessionFactory.class);
//		SessionFactory sessionFactory = (SessionFactory) ctx.getBean("sessionFactory");
		System.out.println(sessionFactory);

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		// 数据库的操作
		
for (int i = 0; i <10; i++) {
	SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
	Date date = new Date();
	CRM_Customer customer = null;
	CRM_Admin admin = null;
	try {
		customer = new CRM_Customer("Zach", "hello", 22, "000-002", "zach@hello.com", "CHN-SHANGHAI", "VIP", sf.parse("1994-04-24"), "Apple", "USA");
		admin = new CRM_Admin("zz","hello", "zz", "zz", "111", sf.parse("1994-04-24"));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	session.save(customer);
	session.save(admin);
}

		tx.commit();
		session.close();

	}
}
