package com.jikexueyuancrm.service;

import com.jikexueyuancrm.entity.CRM_Admin;

public interface ICRM_AdminService {

	public CRM_Admin adminLogin(String admin_account, String admin_password);

}
