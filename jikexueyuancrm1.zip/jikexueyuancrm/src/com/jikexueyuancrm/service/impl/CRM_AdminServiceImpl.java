package com.jikexueyuancrm.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jikexueyuancrm.dao.ICRM_AdminDao;
import com.jikexueyuancrm.entity.CRM_Admin;
import com.jikexueyuancrm.service.ICRM_AdminService;

@Service("adminService")
public class CRM_AdminServiceImpl implements ICRM_AdminService {

	@Resource
	ICRM_AdminDao adminDao;
	
	@Override
	public CRM_Admin adminLogin(String admin_account, String admin_password) {
		
		return adminDao.adminValidate(admin_account, admin_password);
	}

}
