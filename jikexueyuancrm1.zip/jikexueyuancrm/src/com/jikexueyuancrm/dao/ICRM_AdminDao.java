package com.jikexueyuancrm.dao;

import com.jikexueyuancrm.entity.CRM_Admin;

public interface ICRM_AdminDao {

	public CRM_Admin getAdminByAccount(String admin_account);
	public CRM_Admin adminValidate(String admin_account, String admin_password);

}
