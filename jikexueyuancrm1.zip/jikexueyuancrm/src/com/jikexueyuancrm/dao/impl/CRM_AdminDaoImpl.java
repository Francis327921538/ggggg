package com.jikexueyuancrm.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.jikexueyuancrm.dao.ICRM_AdminDao;
import com.jikexueyuancrm.entity.CRM_Admin;

@Repository("adminDao")
public class CRM_AdminDaoImpl implements ICRM_AdminDao {

	@Resource
	SessionFactory sessionFactory;
	
	public Session getSession(){
		
		return sessionFactory.openSession();
	}

	@Override
	public CRM_Admin getAdminByAccount(String admin_account) {
		
		String hql = "from CRM_Admin a where a.admin_account = ?";
		CRM_Admin admin = (CRM_Admin) getSession().createQuery(hql).setParameter(0, admin_account).uniqueResult();
		return admin;
	}
	
	@Override
	public CRM_Admin adminValidate(String admin_account, String admin_password) {
		
		String hql = "from CRM_Admin a where a.admin_account = ? and a.admin_password = ?";
		List list = getSession().createQuery(hql).setParameter(0, admin_account).setParameter(1, admin_password).list();
		if (list.size()>0) {
			return getAdminByAccount(admin_account);
		}
		return null;
	}





}
