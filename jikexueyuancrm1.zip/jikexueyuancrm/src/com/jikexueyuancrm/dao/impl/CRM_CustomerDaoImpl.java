package com.jikexueyuancrm.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.jikexueyuancrm.dao.ICRM_CustomerDao;
import com.jikexueyuancrm.entity.CRM_Customer;

@Repository("customerDao")
public class CRM_CustomerDaoImpl implements ICRM_CustomerDao {

	@Resource
	SessionFactory sessionFactory;
	
	Session getSession() {
		//openSession !important:不用报错 org.hibernate.SessionFactory.openSession()Lorg/hibernate/classic/Session;
		return sessionFactory.openSession();
	}
	
	@Override
	public List<CRM_Customer> getCustomerByID(int id) {
		
		String hql = "from CRM_Customer c where c.customer_id = ?";
		List list = getSession().createQuery(hql).setParameter(0, id).list();
		return list;
	}

	@Override
	public List<CRM_Customer> getAllCustomer() {
		
		String hql = "from CRM_Customer c order by c.customer_id";
		List list = getSession().createQuery(hql).list();
		return list;
	}

	@Override
	public boolean deleteCustomerByID(int id) {
		
		CRM_Customer customer = this.getCustomerByID(id).get(0);
		System.out.println(customer+"dao");
		Session session = this.getSession();
		session.beginTransaction();
		session.delete(customer);
		session.getTransaction().commit();
		session.close();
		return true;
	}

	@Override
	public boolean addCustomer(CRM_Customer customer) {
		
		Session session = this.getSession();
		session.beginTransaction();
		session.save(customer);
		session.getTransaction().commit();
		session.close();
		return true;
	}
}
