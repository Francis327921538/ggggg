package com.jikexueyuancrm.dao.impl;

public class CRM_EnterpriseDaoImpl {

}
