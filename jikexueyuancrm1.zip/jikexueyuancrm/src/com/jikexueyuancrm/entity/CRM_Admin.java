package com.jikexueyuancrm.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="crm_admin")
public class CRM_Admin implements Serializable {

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1353716633580906267L;

	@Id
	@SequenceGenerator(name="sequenceGenerator_admin", sequenceName="CRM_ADMIN_SEQ", initialValue=10000,allocationSize=1)
	@GeneratedValue(generator="sequenceGenerator_admin", strategy=GenerationType.SEQUENCE)
	private int admin_id;
	
	private String admin_account;
	private String admin_password;
	private String admin_name;
	private String admin_email;
	private String admin_phone;
	private Date created_time;
	
	public CRM_Admin() {
		super();
	}

	public CRM_Admin(String admin_account, String admin_password, String admin_name, String admin_email,
			String admin_phone, Date created_time) {
		super();
		this.admin_account = admin_account;
		this.admin_password = admin_password;
		this.admin_name = admin_name;
		this.admin_email = admin_email;
		this.admin_phone = admin_phone;
		this.created_time = created_time;
	}

	public int getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}

	public String getAdmin_account() {
		return admin_account;
	}

	public void setAdmin_account(String admin_account) {
		this.admin_account = admin_account;
	}
	
	public String getAdmin_password() {
		return admin_password;
	}

	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}

	public String getAdmin_name() {
		return admin_name;
	}

	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}

	public String getAdmin_email() {
		return admin_email;
	}

	public void setAdmin_email(String admin_email) {
		this.admin_email = admin_email;
	}

	public String getAdmin_phone() {
		return admin_phone;
	}

	public void setAdmin_phone(String admin_phone) {
		this.admin_phone = admin_phone;
	}

	public Date getCreated_time() {
		return created_time;
	}

	public void setCreated_time(Date created_time) {
		this.created_time = created_time;
	}

	@Override
	public String toString() {
		return "CRM_Admin [admin_id=" + admin_id + ", admin_account=" + admin_account + ", admin_password=" + admin_password
				+ ", admin_name=" + admin_name + ", admin_email=" + admin_email + ", admin_phone=" + admin_phone
				+ ", created_time=" + created_time + "]";
	}

}
