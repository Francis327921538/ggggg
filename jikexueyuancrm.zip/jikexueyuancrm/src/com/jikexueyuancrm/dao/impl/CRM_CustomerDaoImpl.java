package com.jikexueyuancrm.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.jikexueyuancrm.dao.ICRM_CustomerDao;
import com.jikexueyuancrm.entity.CRM_Customer;

@Repository("customerDAO")
public class CRM_CustomerDaoImpl implements ICRM_CustomerDao {

	@Resource
	SessionFactory sessionFactory;
	
	Session getSession() {
		//openSession !important:不用报错 org.hibernate.SessionFactory.openSession()Lorg/hibernate/classic/Session;
		return sessionFactory.openSession();
	}
	
	@Override
	public List<CRM_Customer> getCustomerByCID(String cid) {
		
		String queryString = "from CRM_Customer c where c.customer_id = ?";
		List list = getSession().createQuery(queryString).setParameter(0, cid).list();
		return list;
	}

	@Override
	public List<CRM_Customer> getAllCustomer() {
		
		String queryString = "from CRM_Customer c ";
		List list = getSession().createQuery(queryString).list();
		return list;
	}

	@Override
	public boolean deleteCustomer() {
		
		CRM_Customer customer = this.getCustomerByCID("T1").get(0);
		System.out.println(customer+"dao");
		Session session = this.getSession();
		session.beginTransaction();
		session.delete(customer);
		session.getTransaction().commit();
		session.close();
		return true;
	}
}
