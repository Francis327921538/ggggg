package com.jikexueyuancrm.dao;

public interface ICRM_UserDao {

}
