package com.jikexueyuancrm.dao;

import java.util.List;

import com.jikexueyuancrm.entity.CRM_Customer;

public interface ICRM_CustomerDao {

	public List<CRM_Customer> getCustomerByCID(String cid);
	public List<CRM_Customer> getAllCustomer();
	public boolean deleteCustomer();
}
