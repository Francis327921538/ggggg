package com.jikexueyuancrm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jikexueyuancrm.dao.ICRM_CustomerDao;
import com.jikexueyuancrm.entity.CRM_Customer;
import com.jikexueyuancrm.service.ICRM_CustomerService;

@Service("customerService")
public class CRM_CustomerServiceImpl implements ICRM_CustomerService {

	@Resource
	ICRM_CustomerDao customerDAO;
	@Override
	public List<CRM_Customer> getCustomerByCID(String cid) {
		
		List<CRM_Customer> list = customerDAO.getCustomerByCID(cid);
		return list;
	}
	@Override
	public List<CRM_Customer> getAllCustomer() {
		
		List<CRM_Customer> list = customerDAO.getAllCustomer();
		return list;		
	}
	@Override
	public boolean deleteCustomer() {
		
		return customerDAO.deleteCustomer();
	}

}
