package com.jikexueyuancrm.service;

import java.util.List;

import com.jikexueyuancrm.entity.CRM_Customer;

public interface ICRM_CustomerService {
	
	public List<CRM_Customer> getCustomerByCID(String cid);
	public List<CRM_Customer> getAllCustomer();
	public boolean deleteCustomer();
}
