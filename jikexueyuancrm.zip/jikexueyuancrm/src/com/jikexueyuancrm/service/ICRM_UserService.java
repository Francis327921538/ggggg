package com.jikexueyuancrm.service;

public interface ICRM_UserService {

}
