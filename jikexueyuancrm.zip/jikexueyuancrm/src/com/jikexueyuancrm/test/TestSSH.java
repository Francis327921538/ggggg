package com.jikexueyuancrm.test;

import static org.junit.Assert.fail;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jikexueyuancrm.entity.CRM_Customer;
import com.jikexueyuancrm.entity.CRM_Enterprise;
import com.jikexueyuancrm.entity.CRM_User;

public class TestSSH {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

	private ApplicationContext ctx = null;

	@Test
	public void testDataSource() throws SQLException {
		ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		// System.out.println(ctx);
		DataSource dataSource = ctx.getBean(DataSource.class);

		// System.out.println(dataSource.getConnection().toString());

		SessionFactory sessionFactory = ctx.getBean(SessionFactory.class);
//		SessionFactory sessionFactory = (SessionFactory) ctx.getBean("sessionFactory");
		System.out.println(sessionFactory);

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		// 数据库的操作
//		CRM_User crm_user = new CRM_User("Auger2", "123456", "周哥2",
//				"12312312@qq.com", "18575590214", 234234234);
//		session.save(crm_user);
		
		CRM_Enterprise enterprise = new CRM_Enterprise("E1", "Google", "00-01", "USA", "Technology", "iphone");
		CRM_Customer customer = new CRM_Customer("T1", "Rose", "hello", 18, "000-003", "rose@hello.com", "CHN_SHANGHAI", enterprise);
//		session.save(enterprise);
		session.save(customer);
		tx.commit();
		session.close();

	}
}
