package com.jikexueyuancrm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/enterprise")
public class CRM_EnterpriseController {
	
	@RequestMapping("/hello")
	public String hello(){
		
		System.out.println("asda");
		return "add";
	}
}
