package com.jikexueyuancrm.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jikexueyuancrm.dao.ICRM_CustomerDao;

@Controller
@RequestMapping("/user")
public class CRM_UserController {
	
	@Resource
	ICRM_CustomerDao customerDAO;
	
	@RequestMapping("/hello")
	public String hello(){
		
		System.out.println(customerDAO.getCustomerByCID("C1").size());
		System.out.println("asda");
		return "add";
	}
}
