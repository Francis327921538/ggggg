package com.jikexueyuancrm.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import com.jikexueyuancrm.entity.CRM_Customer;
import com.jikexueyuancrm.service.ICRM_CustomerService;

@Controller
@RequestMapping("/customer")
public class CRM_CustomerController {
	
	@Resource
	ICRM_CustomerService customerService;
	
	@RequestMapping("/hello")
	public ModelAndView hello(){
		
		ModelAndView modelAndView = new ModelAndView("hello");
		List<CRM_Customer> customers = new ArrayList<>();
		customers = customerService.getAllCustomer();
		modelAndView.addObject("cus", customers);
		return modelAndView;
	}
//	@ResponseBody
//	@RequestMapping("/cus")
//	public Map listAllCustomerAjax(){
//		
//		System.out.println("cus1");
//		List<CRM_Customer> customers = customerService.getAllCustomer();
//		Map<String,Object> map = new HashMap<String,Object>();
//		map.put("cus", customers);
//		return map;
//	}
	@ResponseBody
	@RequestMapping("/lsitCustomer")
	public List listAllCustomerAjax(){
		
		List<CRM_Customer> customers = customerService.getAllCustomer();
		return customers;
	}
	
	@RequestMapping("/say")
	public void say(){
		
		System.out.println("hello");
	}
	
	@ResponseBody
	@RequestMapping("deleteCustomer")
	public boolean deleteCustomer(){
		
		System.out.println("deleteCus");
		customerService.deleteCustomer();
		return true;
	}
}
