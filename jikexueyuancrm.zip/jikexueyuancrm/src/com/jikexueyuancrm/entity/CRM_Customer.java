package com.jikexueyuancrm.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "crm_customer")
public class CRM_Customer implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6833930062621866613L;
	
	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid")
	private String id;
	
	private String customer_id;
	private String customer_name;
	private String customer_password;
	private int customer_age;
	private String customer_tel;
	private String customer_email;
	private String customer_address;
	
	@ManyToOne
	@JoinColumn(name = "enterprise_id")
	private CRM_Enterprise enterprise;

	
	
	public CRM_Customer() {
		super();
	}

	public CRM_Customer(String customer_id, String customer_name, String customer_password, int customer_age,
			String customer_tel, String customer_email, String customer_address, CRM_Enterprise enterprise) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.customer_password = customer_password;
		this.customer_age = customer_age;
		this.customer_tel = customer_tel;
		this.customer_email = customer_email;
		this.customer_address = customer_address;
		this.enterprise = enterprise;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getCustomer_password() {
		return customer_password;
	}

	public void setCustomer_password(String customer_password) {
		this.customer_password = customer_password;
	}

	public int getCustomer_age() {
		return customer_age;
	}

	public void setCustomer_age(int customer_age) {
		this.customer_age = customer_age;
	}

	public String getCustomer_tel() {
		return customer_tel;
	}

	public void setCustomer_tel(String customer_tel) {
		this.customer_tel = customer_tel;
	}

	public String getCustomer_email() {
		return customer_email;
	}

	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}

	public String getCustomer_address() {
		return customer_address;
	}

	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}

	public CRM_Enterprise getEnterprise() {
		return enterprise;
	}

	public void setEnterprise(CRM_Enterprise enterprise) {
		this.enterprise = enterprise;
	}

	@Override
	public String toString() {
		return "CRM_Customer [id=" + id + ", customer_id=" + customer_id + ", customer_name=" + customer_name
				+ ", customer_password=" + customer_password + ", customer_age=" + customer_age + ", customer_tel="
				+ customer_tel + ", customer_email=" + customer_email + ", customer_address=" + customer_address
				+ ", enterprise=" + enterprise + "]";
	}
	
	
	
}
