package com.jikexueyuancrm.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name = "crm_enterprise")
public class CRM_Enterprise implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3840742150040201683L;
	
	@Id
	private String enterprise_id;
	private String enterprise_name;
	private String enterprise_tel;
	private String enterprise_address;
	private String enterprise_type;
	private String enterprise_desc;
	
	@OneToMany
	@Cascade(value={CascadeType.SAVE_UPDATE})
	@JoinColumn(name = "enterprise_id")
	private Set<CRM_Customer> customers = new HashSet<>();
	
	public CRM_Enterprise() {
		super();
	}
	public CRM_Enterprise(String enterprise_id, String enterprise_name, String enterprise_tel,
			String enterprise_address, String enterprise_type, String enterprise_desc) {
		super();
		this.enterprise_id = enterprise_id;
		this.enterprise_name = enterprise_name;
		this.enterprise_tel = enterprise_tel;
		this.enterprise_address = enterprise_address;
		this.enterprise_type = enterprise_type;
		this.enterprise_desc = enterprise_desc;
	}
	public String getEnterprise_id() {
		return enterprise_id;
	}
	public void setEnterprise_id(String enterprise_id) {
		this.enterprise_id = enterprise_id;
	}
	public String getEnterprise_name() {
		return enterprise_name;
	}
	public void setEnterprise_name(String enterprise_name) {
		this.enterprise_name = enterprise_name;
	}
	public String getEnterprise_tel() {
		return enterprise_tel;
	}
	public void setEnterprise_tel(String enterprise_tel) {
		this.enterprise_tel = enterprise_tel;
	}
	public String getEnterprise_address() {
		return enterprise_address;
	}
	public void setEnterprise_address(String enterprise_address) {
		this.enterprise_address = enterprise_address;
	}
	public String getEnterprise_type() {
		return enterprise_type;
	}
	public void setEnterprise_type(String enterprise_type) {
		this.enterprise_type = enterprise_type;
	}
	public String getEnterprise_desc() {
		return enterprise_desc;
	}
	public void setEnterprise_desc(String enterprise_desc) {
		this.enterprise_desc = enterprise_desc;
	}
	@Override
	public String toString() {
		return "CRM_Enterprise [enterprise_id=" + enterprise_id + ", enterprise_name=" + enterprise_name
				+ ", enterprise_tel=" + enterprise_tel + ", enterprise_address=" + enterprise_address
				+ ", enterprise_type=" + enterprise_type + ", enterprise_desc=" + enterprise_desc + "]";
	}
	
	
}
